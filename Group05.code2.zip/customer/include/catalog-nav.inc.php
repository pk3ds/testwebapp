<div class="col-md-3 d-none d-md-block"><!--Only visible on 992px and up screen-->
	<h2>More products</h2>
	<p>Check out more awesome products</p>
	<ul class="nav nav-pills flex-column" role="tab-list"><!--Side left navbar-->
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=1">A4</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=2">Banner</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=3">Brochure</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=4">Calendar</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=5">Name Card</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="product_catalog.php?ID=6">Poster</a>
		</li>
	</ul>
	<hr />
</div>